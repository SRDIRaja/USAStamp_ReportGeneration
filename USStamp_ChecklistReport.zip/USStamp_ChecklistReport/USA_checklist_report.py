"""
Generate As-built Checklist Report

Version 0.0.1
"""
from os.path import dirname
from time import perf_counter
from json import loads
import logging

import arcpy

from asbuilt_checklist_publisher.constants import (
    FEATURES, ATTRIBUTES, GLOBAL_ID_FIELD)
from asbuilt_checklist_publisher.exceptions import ErrorBadInputFeatures, BaseErrorToUser
from asbuilt_checklist_publisher.report import ReportTables
from asbuilt_checklist_publisher.configuration import Configuration
from asbuilt_checklist_publisher.utils import merge_pdf

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] - %(message)s",
    datefmt="%Y-%m-%d %I:%M:%S %p"
)


def get_asbuilt_checklist_id() -> str:
    """
    Get the As-built Checklist id from the given feature set

    Returns:
        as-built-checklist-id: integer,

    """
    feature_set = arcpy.GetParameter(0)
    feature_set = arcpy.FeatureSet(feature_set)
    feature_set = loads(feature_set.JSON)
    features = feature_set.get(FEATURES)

    if not features or len(features) != 1:
        message = 'None' if not features else len(features)
        raise ErrorBadInputFeatures(
            f"Please select only one feature. Received {message}."
        )

    feature = features[0]
    attributes = feature.get(ATTRIBUTES)
    arcpy.AddMessage(feature)
    arcpy.AddMessage(attributes)

    attr_issues = "Features Set has not attributes"
    if not attributes:
        raise ErrorBadInputFeatures(attr_issues)
    
    asbuilt_checklist_globalid = attributes.get(GLOBAL_ID_FIELD)
    arcpy.AddMessage(asbuilt_checklist_globalid)
    if asbuilt_checklist_globalid is None:
        raise ErrorBadInputFeatures(attr_issues)
    return asbuilt_checklist_globalid
# End asbuilt_get function


def reporter() -> None:
    """
    Reporter

    Returns: Nothing

    """
    asbuilt_checklist_globalid = get_asbuilt_checklist_id()
    #asbuilt_checklist_globalid = '{CF2527B8-7CD6-482C-9269-C82D1042FC8F}'

    config = Configuration(asbuilt_checklist_globalid, dirname(__file__))
    logging.info(f'Output Location: {config.output_location}')
    logging.info(f'Database Location: {config.database_path}')
    pages = ReportTables(config)()
    final = merge_pdf(pages, asbuilt_checklist_globalid, config.output_location)
    arcpy.SetParameterAsText(1, final)
    # Todo - call cleanup (Might need to close the temp_aprx file first and delete it)
# End of reporter function


if __name__ == '__main__':
    arcpy.env.overwriteOutput = True
    logging.info('As-built Checklist Report Start')
    start = perf_counter()
    try:
        reporter()
    except Exception as e:
        if isinstance(e, BaseErrorToUser):
            # Expected / Handled errors aka user errors
            arcpy.AddError(str(e))
            logging.error(str(e))
        else:
            # other errors
            msg = (f'Encountered unexpected error: {str(e)}.'
                   f'Please contact admin.')
            arcpy.AddError(msg)
            logging.exception(msg)
    logging.info('As-built Checklist Report Complete')
    elapsed = perf_counter() - start
    logging.info(f'Elapsed Time: {round(elapsed, 0)} seconds.')
