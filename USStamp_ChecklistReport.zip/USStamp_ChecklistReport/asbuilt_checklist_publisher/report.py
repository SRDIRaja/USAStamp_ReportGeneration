"""
Report
"""

from os.path import join
from typing import List
import logging

from asbuilt_checklist_publisher.configuration import Configuration
from asbuilt_checklist_publisher.constants import (
    ASBUILT_CHECKLIST_LAYOUT_PAGE1,TEXT_ELEMENT)


class BaseReport(object):
    """
    Base Report Class
    """
    def __init__(self, config: Configuration):
        """
        Generate the As-built Checklist Report

        Args:
            config:
        """
        self.config = config
    # End of BaseReport initialization
# End of BaseReport Class


class ReportTables(BaseReport):
    """
    As-built Checklist Report Class
    """
    def __call__(self, *args, **kwargs):
        """
        Makes the class callable

        Args:
            *args:
            **kwargs:

        Returns:
            Pages
        """
        pages = self.get_table_pages()
        return pages
    # End of ReportTables initialization

    def replace_static_values(self, layout):
        """
        Replace all the static values from layout

        Args:
            layout: layout of template aprx

        Returns:

        """
        elements = layout.listElements(TEXT_ELEMENT)
        for element in elements:
            value = self.config.static_element_data.get(element.name, None)
            if value is None:
                continue
            # TODO - number or dates can be formatted
            element.text = str(value)
    # End of replace_static_values method

    def get_table_pages(self) -> List:
        """
        Table pages for the report

        Returns:
            pdf with static tabular
        """
        pages = []
        layout_names = [ASBUILT_CHECKLIST_LAYOUT_PAGE1]
        for layout_name in layout_names:
            layout = self.config.working_project.layouts_by_name.get(
                layout_name)
            self.replace_static_values(layout)
            table_page_pdf = join(
                self.config.output_location, f'{layout_name}.pdf')
            logging.info(f'Completed {layout_name}.pdf')
            layout.exportToPDF(table_page_pdf)
            pages.append(table_page_pdf)
        return pages
    # End of get_table_pages property

# End of Report table class


if __name__ == '__main__':
    pass
