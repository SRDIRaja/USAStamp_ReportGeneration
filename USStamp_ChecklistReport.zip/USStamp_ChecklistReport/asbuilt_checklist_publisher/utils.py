"""
Utility Functions
"""

import logging
from datetime import datetime
from os import remove
from os.path import join, exists
from typing import Dict, List
from json import load
from uuid import uuid4

import arcpy
from PyPDF2 import PdfFileMerger

from asbuilt_checklist_publisher.schema import FieldValue
from asbuilt_checklist_publisher.constants import (
    DATASET, FIELD_NAME, TRIPLE_DASH, MAB_ASBUILT_CHECKLIST_NAME, MAB_CONSTR_NAME,
    SPECIAL_FIELDS
)


def copy_template_aprx(template_aprx: str, output_location: str) -> str:
    """
    Make a copy of the template aprx

    Args:
        template_aprx:
        output_location:

    Returns:

    """
    aprx = arcpy.mp.ArcGISProject(template_aprx)
    unique_name = f'temp_{uuid4().hex}.aprx'
    temp_file_location = join(output_location, unique_name)
    aprx.saveACopy(temp_file_location)
    del aprx
    return temp_file_location
# End of the copy_template_aprx function


def merge_pdf(pages: List[str], asbuilt_checklist_id: str, output_location: str) -> str:
    """
    Merge PDFs

    Args:
        pages: list of pages
        asbuilt_checklist_id: integer
        output_location: path as string

    Returns:
        string with output pdf name

    """
    filename = (f"US-Stamp Checklist Report - {asbuilt_checklist_id} "
                f" - {datetime.now().strftime('%Y%m%d%H%M%S%f')}.pdf")
    merger = PdfFileMerger()
    out_pdf_name = join(output_location, filename)
    for page in pages:
        if exists(page):
            merger.append(page)
    merger.write(out_pdf_name)
    merger.close()
    return out_pdf_name


# End of merge pdf function


def cleanup(pages: List[str]):
    """
    Clean up the pages if possible

    Args:
        pages:

    Returns:

    """
    for page in pages:
        if exists(page):
            try:
                remove(page)
            except (FileExistsError, FileNotFoundError, Exception):
                logging.debug(f'Unable to remove {page}')
                pass
# End of cleanup function


def get_fc_record(feature_class: str, query: str,
                  workspace_domains: Dict[str, Dict]) -> Dict[str, FieldValue]:
    """
    Get a feature class record as a dictionary

    Args:
        feature_class: path to a feature class
        query: Query to use: should only return one record
        workspace_domains: required Domains for this report

    Returns:
        Dict of field values

    """
    logging.debug(f'get_fc_record: feature_class: {feature_class}')
    desc = arcpy.Describe(feature_class)
    fields = [field for field in desc.fields
              if field.type.lower() not in SPECIAL_FIELDS]
    field_names = [field.name for field in fields]
    data = {}
    with arcpy.da.SearchCursor(in_table=feature_class, field_names=field_names,
                               where_clause=query) as cursor:
        for row in cursor:
            for field, value in zip(fields, row):
                domain = workspace_domains.get(field.domain, {})
                coded_value = domain.get(value, None)
                data[field.name] = FieldValue(value, coded_value)
            break
            # NOTE - It should Iterate one time -> main input has validation
    return data
# End of get_fc_record


def get_static_element_data(
        static_element_json: str,
        as_built_checklist_dict: Dict[str, FieldValue],
        project_dict: Dict[str, FieldValue]) -> Dict:
    """
    Get Static Element Data

    Args:
        static_element_json: Json with lookup of elements and fields
        as_built_checklist_dict: as_built_checklist_record as dictionary
        project_dict: project record as dictionary

    Returns:
        returns all the static element data with values as dictionary

    """
    lookup = {}
    with open(static_element_json) as fin:
        json_data = load(fin)

    for element_name, element_details in json_data.items():
        dataset = element_details.get(DATASET)
        field_name = element_details.get(FIELD_NAME)
        value = TRIPLE_DASH
        if dataset == MAB_ASBUILT_CHECKLIST_NAME:
            value = as_built_checklist_dict.get(field_name)
            if value:
                value = value.display_value
        elif dataset == MAB_CONSTR_NAME:
            value = project_dict.get(field_name)
            if value:
                value = value.display_value
        lookup[element_name] = value
    return lookup
# End of get_static_element_data function


def get_required_domains_by_name(feature_classes: List[str]) -> List[str]:
    """
    Get all the domains by name that is required for this project

    Args:
        feature_classes:

    Returns:

    """
    domains_by_name = set()
    for fc in feature_classes:
        fields = arcpy.ListFields(fc)
        for field in fields:
            if field.domain != "":
                domains_by_name.add(field.domain)
    return list(domains_by_name)
# End of get_required_domain_by_name function


if __name__ == '__main__':
    pass
