"""
Schema classes
"""


class FieldValue(object):
    """
    Field Value
    """
    def __init__(self, value, coded_value):
        """
        Initialization

        Args:
            value:
            coded_value:
        """
        self.value = value
        self.coded_value = coded_value
    # End of init

    @property
    def display_value(self) -> str:
        """
        Display value

        Returns:
            field value to be displayed
        """
        if self.coded_value is not None:
            return self.coded_value
        return self.value
    # End of display value property

# End of Field Value class
# TODO- Add FeatureData class if needed!!


if __name__ == '__main__':
    pass
