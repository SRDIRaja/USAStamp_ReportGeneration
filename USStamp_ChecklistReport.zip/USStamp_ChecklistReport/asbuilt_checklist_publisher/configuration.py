"""
Configuration class to pull around config details
"""

from os.path import join
from typing import Dict
from json import load

import arcpy

from asbuilt_checklist_publisher.constants import (
    RESOURCES, CONFIG_JSON, STATIC_ELEMENT_JSON, ConfigKeywords,
    TEMPLATE_APRX, MAB_ASBUILT_CHECKLIST_NAME,
    MAB_CONSTR_NAME, GLOBAL_ID_FIELD, PROJECT_GLOBAL_ID)
from asbuilt_checklist_publisher.lazy_prop import lazy_property
from asbuilt_checklist_publisher.pro import ProProject
from asbuilt_checklist_publisher.schema import FieldValue
from asbuilt_checklist_publisher.utils import get_static_element_data, \
    get_required_domains_by_name, get_fc_record, copy_template_aprx


class Configuration(object):
    """
    Configuration class
    """
    def __init__(self, asbuilt_checklist_id: str, location: str):
        """
        Configuration initialization

        Args:
            asbuilt_checklist_id:
            location:
        """
        self.asbuilt_checklist_globalid = asbuilt_checklist_id
        self.location = location
        self.resource_location = join(location, RESOURCES)
        self.config_file = join(self.resource_location, CONFIG_JSON)
        self.static_element_file = join(self.resource_location, STATIC_ELEMENT_JSON)
    # End of init built-in

    @lazy_property
    def output_location(self) -> str:
        """
        Output location (depending on server/local)

        Returns:
            string of output location

        """
        if self.environment == ConfigKeywords.local:
            return self.environment_props.get(ConfigKeywords.debug_output)
        return arcpy.env.scratchFolder
    # End of output_location property

    @lazy_property
    def environment(self) -> str:
        """
        Get the Environment

        Returns:
            string

        """
        environment = self.config_data.get(ConfigKeywords.environment)
        if environment not in (ConfigKeywords.local, ConfigKeywords.development, ConfigKeywords.production):
            raise ValueError(f'Invalid environment specified in config file: '
                             f'{environment}')
        return environment
    # End of environment property

    @lazy_property
    def config_data(self) -> Dict:
        """
        Config data

        Returns:
            Dictionary of config data

        """
        with open(self.config_file) as fin:
            json_data = load(fin)
        return json_data
    # End of config data property

    @lazy_property
    def environment_props(self) -> Dict:
        """
        Environment props

        Returns:
            Dictionary of environments
        """
        return self.config_data.get(self.environment)
    # End of environment_props property

    @property
    def database_path(self) -> str:
        """
        Database path

        Returns:
            String of Database path
        """
        return self.environment_props.get(ConfigKeywords.database_connection)
    # End of database_path property

    @lazy_property
    def working_project(self) -> ProProject:
        """
        Table Template Project
        NOTE - Not making copy of aprx. Just using directly from resource/asbuilt_checklist_templates.aprx

        Returns:
            Template APRX Project

        """

        temp_aprx_file = copy_template_aprx(
            join(self.resource_location, TEMPLATE_APRX), self.output_location)
        return ProProject(temp_aprx_file)
    # End of working_project property

    @lazy_property
    def local(self) -> bool:
        """
        local or not

        Returns:
            bool

        """
        value = self.config_data.get(ConfigKeywords.environment)
        return (True if value and value.lower() == ConfigKeywords.local
                else False)
    # End of local property

    @lazy_property
    def as_built_fd(self) -> str:
        """
        As built FD path

        Returns:

        """
        return self.environment_props.get(ConfigKeywords.as_built_fd)
    # End of as_built_fd property

    @lazy_property
    def schema(self) -> str:
        """
        Schema name for the feature class

        Returns:

        """
        return self.environment_props.get(ConfigKeywords.schema)
    # End of schema property

    @lazy_property
    def partial_path(self) -> str:
        """
        Partial path to feature dataset data

        Returns:

        """
        return f'{self.schema}.{self.as_built_fd}/{self.schema}'
    # End of partial_path property

    def _make_path(self, name) -> str:
        """
        Make path for given feature class
        Returns:

        """
        if self.local:
            return join(self.database_path, name)
        relative = f'{self.partial_path}.{name}'
        return join(self.database_path, relative)
    # End of _make_path method

    @lazy_property
    def as_built_checklist_fc_path(self) -> str:
        """
        Get the As-Built Checklist feature class path

        Returns:

        """
        return self._make_path(MAB_ASBUILT_CHECKLIST_NAME)
    # End of as_built_checklist_fc_path property

    @lazy_property
    def project_fc_path(self) -> str:
        """
        Get the Project feature class path

        Returns:

        """
        return self._make_path(MAB_CONSTR_NAME)
    # End of Project_fc_path property

    def filter_by_required_domains(self, list_of_required_domains) -> Dict:
        """
        Filter out required ones from all domains

        Args:
            list_of_required_domains: domains names that are required

        Returns:

        """
        data = {}
        domains = arcpy.da.ListDomains(self.database_path)
        for domain in domains:
            if domain.name in list_of_required_domains:
                data[domain.name] = domain.codedValues
        return data
    # End of filter_by_required_domains method

    @lazy_property
    def required_workspace_domains(self) -> Dict[str, Dict]:
        """
        Get the domains dictionary

        Returns:
            dictionary that gets the coded value dictionary by name of domain

        """
        list_of_feature_classes_path = [self.as_built_checklist_fc_path, self.project_fc_path]
        required_domains_by_name = get_required_domains_by_name(list_of_feature_classes_path)
        return self.filter_by_required_domains(required_domains_by_name)
    # End of required_workspace_domains property

    @lazy_property
    def as_built_checklist_record(self) -> Dict[str, FieldValue]:
        """
        The As-Built Checklist Record

        Returns:
            Dictionary of as_built_checklist

        """
        query = f"{GLOBAL_ID_FIELD} = '{self.asbuilt_checklist_globalid}'"
        return get_fc_record(self.as_built_checklist_fc_path, query,
                             self.required_workspace_domains)
    # End of as_built_checklist_record property

    @lazy_property
    def project_id(self):
        """
        The project id with the as-built_checklist

        Returns:

        """
        try:
            field_value = self.as_built_checklist_record.get(PROJECT_GLOBAL_ID)
            return field_value.value
        except AttributeError:
            return None
    # End of project_id

    @lazy_property
    def project_record(self) -> Dict[str, FieldValue]:
        """
        Project Record

        Returns:
            Dictionary of project feature class associated with as-built_checklist

        """
        query = f"{GLOBAL_ID_FIELD} = '{self.project_id}'"
        return get_fc_record(self.project_fc_path, query,
                             self.required_workspace_domains)
    # End of project_record property

    @lazy_property
    def static_element_data(self) -> Dict:
        """
        Static Element json data

        Returns:
            Dictionary of element data

        """
        return get_static_element_data(
            self.static_element_file,
            self.as_built_checklist_record,
            self.project_record
        )
    # End of static_element_data property

# End Configuration Class


if __name__ == "__main__":
    pass
