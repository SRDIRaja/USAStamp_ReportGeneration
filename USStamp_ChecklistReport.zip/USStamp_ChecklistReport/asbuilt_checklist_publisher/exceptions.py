"""
Exceptions
"""


class BaseErrorToUser(Exception):
    """
    Base Error to User
    """
    pass


class ErrorBadInputFeatures(BaseErrorToUser):
    """
    Error for Bad features input
    """
    pass
