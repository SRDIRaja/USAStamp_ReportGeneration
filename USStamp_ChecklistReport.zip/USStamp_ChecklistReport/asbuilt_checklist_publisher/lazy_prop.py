"""
Custom Lazy Property
"""

# Property name to hold all lazy date
_data_holder_attr = '_lazy_properties'


class lazy_property(object):
    """
    Lazy property decorator, just like built-in 'property'
    """
    def __init__(self, fget):
        """
        Initialization

        Args:
            fget:
        """
        self.fget = fget
        self.property_name = fget.__name__

    def get_lazy_data(self, instance):
        """
        Get Lazy Data

        Args:
            instance:

        Returns:
            nothing

        """
        if not hasattr(instance, _data_holder_attr):
            setattr(instance, _data_holder_attr, {})
        return getattr(instance, _data_holder_attr)
    # End get_lazy_data method

    def __get__(self, instance, owner):
        """
        Get builtin

        Args:
            instance:
            owner:

        Returns:

        """
        if instance is None:
            return None

        lazy_data = self.get_lazy_data(instance)

        if self.property_name in lazy_data:
            return lazy_data[self.property_name]

        value = self.fget(instance)
        lazy_data[self.property_name] = value
        return value
    # End get builtin

# End of lazy property decorator


if __name__ == '__main__':
    pass
