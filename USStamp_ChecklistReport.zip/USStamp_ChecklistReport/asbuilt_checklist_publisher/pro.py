"""
Pro Project Wrapper. Very simple for now
"""

from typing import Dict

import arcpy

from asbuilt_checklist_publisher.lazy_prop import lazy_property


class ProProject(object):
    """
    Pro Project
    """
    def __init__(self, path_to_aprx):
        """
        Initialization of Pro Project

        Args:
            path_to_aprx:
        """
        self._path_to_aprx = path_to_aprx
        self.aprx = arcpy.mp.ArcGISProject(path_to_aprx)
    # End of ProProject initialization

    @lazy_property
    def layouts_by_name(self) -> Dict:
        """
        Layouts by name

        Returns:
            Dict of layouts by name
        """
        return dict((layout.name, layout) for layout in self.aprx.listLayouts())
    # End layouts_by_name_property

# End of Pro Project class


if __name__ == '__main__':
    pass
