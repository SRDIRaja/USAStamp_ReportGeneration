"""
Constants for use with code base
"""

# Dataset Names
MAB_ASBUILT_CHECKLIST_NAME = 'MABUSA_811_stamp'
MAB_CONSTR_NAME = 'MABConstrProjects'

# Resource Names
RESOURCES = 'resources'
TEMPLATE_APRX = 'USAStamp_templates.aprx'
CONFIG_JSON = 'config.json'
STATIC_ELEMENT_JSON = 'static_element_data_sources.json'
ASBUILT_CHECKLIST_LAYOUT_PAGE1 = 'AsBuiltChecklistPage1'



# Keywords
FEATURES = 'features'
DATASET = 'dataset'
FIELD_NAME = 'field_name'
ATTRIBUTES = 'attributes'
TRIPLE_DASH = '- - -'
TEXT_ELEMENT = 'TEXT_ELEMENT'

# Field Names
OID_FIELD_TYPE = 'oid'
GEOM_FIELD_TYPE = 'shape'
SPECIAL_FIELDS = [OID_FIELD_TYPE, GEOM_FIELD_TYPE]
ASBUILT_CHECKLIST_ID_FIELD = 'as_built_checklist_id'
PROJECT_NAME_FIELD = 'projectname'
PROJECT_NUMBER_FIELD = 'projectnumber'
GLOBAL_ID_FIELD = 'globalid'  # TODO - For local change it to {GlobalID}
PROJECT_GLOBAL_ID = 'project_globalid'


# Class for the configuration
class ConfigKeywords(object):
    """
    Config keywords for the JSON file
    """
    local = 'local'
    database_connection = 'database_connection'
    schema = 'schema'
    as_built_fd = 'as_built_fd'
    environment = 'environment'
    development = 'development'
    production = 'production'
    debug_output = 'debug_output'
# End of ConfigKeywords class


if __name__ == '__main__':
    pass
